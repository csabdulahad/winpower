Set-Location 'c:/winpower';

# Include the library functions
. "lib/func";
. "lib/Paramize";

try {

    $pm = [Paramize]::new();
    $pm.cmd(@{
        cmd = 'get'
        options = @(1, "2", 3)
    });

    $pm.validate($args);

    if ($pm.hitCmd('get')) {
        Write-Host 'welcome to get';
        Write-Host ($pm.hitCmdArg('get'));
    }

} catch {
    Err;
}